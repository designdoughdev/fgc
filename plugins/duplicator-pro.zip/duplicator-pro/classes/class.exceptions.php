<?php

class DUP_PRO_NoScanFileException extends Exception
{
}

class DUP_PRO_JsonDecodeException extends Exception
{
}

class DUP_PRO_NoFileListException extends Exception
{
}


class DUP_PRO_NoDirListException extends Exception
{
}
