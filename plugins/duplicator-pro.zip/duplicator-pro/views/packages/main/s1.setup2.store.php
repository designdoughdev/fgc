<?php

use Duplicator\Controllers\StoragePageController;
use Duplicator\Core\CapMng;
use Duplicator\Models\Storages\AbstractStorageEntity;
use Duplicator\Models\Storages\StoragesUtil;

defined("ABSPATH") or die("");

$global       = DUP_PRO_Global_Entity::getInstance();
$storage_list = AbstractStorageEntity::getAll(0, 0, [StoragesUtil::class, 'sortByPriority']);

$langLocalDefaultMsg = __('Recovery Point Capable', 'duplicator-pro');
$ui_css_storage      = (DUP_PRO_UI_ViewState::getValue('dup-pack-storage-panel') ? 'display:block' : 'display:none');

$newStorageUrl = StoragePageController::getEditUrl();
?>

<!-- ===================
META-BOX: STORAGE -->
<div class="dup-box" id="dup-pack-storage-panel-area">
    <div class="dup-box-title" id="dpro-store-title">
        <i class="fas fa-server fa-sm"></i> <?php esc_html_e('Storage', 'duplicator-pro') ?> <sup id="dpro-storage-title-count" class="dup-box-title-badge"></sup>
        <button class="dup-box-arrow">
            <span class="screen-reader-text"><?php esc_html_e('Toggle panel:', 'duplicator-pro') ?> <?php esc_html_e('Storage Options', 'duplicator-pro') ?></span>
        </button>
    </div>          

    <div class="dup-box-panel" id="dup-pack-storage-panel" style="<?php echo esc_attr($ui_css_storage); ?>">
        <div style="padding:0 0 4px 0">
            <?php esc_html_e('Choose the storage location(s) where the archive and installer files will be saved.', 'duplicator-pro') ?>
        </div>
        <table class="widefat pack-store-tbl">
        <thead>
            <tr>
                <th style='white-space: nowrap; width:10px;'></th>
                <th style='width:175px'><?php esc_html_e('Type', 'duplicator-pro') ?></th>
                <th style='width:275px'><?php esc_html_e('Name', 'duplicator-pro') ?></th>
                <th style="white-space: nowrap"><?php esc_html_e('Location', 'duplicator-pro') ?></th>
            </tr>
        </thead>
        <tbody>
        <?php
        $i                  = 0;
        $selectedStorageIds = $global->getManualModeStorageIds();
        foreach ($storage_list as $storage) {
            try {
                if (!$storage->isSupported()) {
                    continue;
                }

                $i++;
                $is_valid       = $storage->isValid();
                $is_checked     = in_array($storage->getId(), $selectedStorageIds) && $is_valid;
                $mincheck       = ($i == 1) ? 'data-parsley-mincheck="1" data-parsley-required="true"' : '';
                $row_style      = ($i % 2) ? 'alternate' : '';
                $row_style     .= ($is_valid) ? '' : ' storage-missing';
                $row_chkid      = "dup-chkbox-{$storage->getId()}";
                $storageEditUrl = StoragePageController::getEditUrl($storage);
                ?>
                <tr class="package-row <?php echo esc_attr($row_style); ?>">
                    <td>
                        <input name="edit_id" type="hidden" value="<?php echo intval($i); ?>" />
                        <input 
                            class="duppro-storage-input" 
                            id="<?php echo $row_chkid; ?>"
                            name="_storage_ids[]"
                            onclick="DupPro.Pack.UpdateStorageCount(); return true;"
                            data-parsley-errors-container="#storage_error_container" <?php echo $mincheck; ?>
                            type="checkbox"
                            value="<?php echo $storage->getId(); ?>"
                            <?php disabled($is_valid == false); ?>
                            <?php checked($is_checked); ?> 
                        >
                    </td>
                    <td>
                        <label for="<?php echo $row_chkid; ?>" class="dup-store-lbl">
                        <?php
                            echo $storage->getStypeIcon() . '&nbsp;' . esc_html($storage->getStypeName());
                            echo ($storage->isLocal())
                                ? "<sup title='{$langLocalDefaultMsg}'><i class='fas fa-house-fire fa-fw fa-sm'></i></sup>"
                                : '';
                        ?>
                        </label>
                    </td>
                    <td>
                        <a href="<?php echo $storageEditUrl; ?>" target="_blank">
                            <?php
                                echo ($is_valid == false)  ? '<i class="fa fa-exclamation-triangle fa-sm"></i> '  : '';
                                echo esc_html($storage->getName());
                            ?>
                        </a>
                    </td>
                    <td>
                        <?php echo $storage->getHtmlLocationLink();?>
                    </td>
                </tr>
                <?php
            } catch (Exception $e) {
                echo "<tr><td colspan='5'><i>"
                . __('Unable to load storage type.  Please validate the setup.', 'duplicator-pro')
                . "</i></td></tr>";
            }
        }
        ?>
        </tbody>
        </table>
        <div style="text-align: right; margin:4px 4px -4px 0; padding:0; width: 100%">
            <?php if (CapMng::can(CapMng::CAP_STORAGE, false)) { ?>
                <a href="<?php echo esc_url($newStorageUrl); ?>" target="_blank">
                    [<?php esc_html_e('Add Storage', 'duplicator-pro') ?>]
                </a>
            <?php } else { ?>
                &nbsp;
            <?php } ?>
        </div>
    </div>
</div>

<div id="storage_error_container" class="duplicator-error-container"></div>

<script>
    jQuery(function ($)
    {
        DupPro.Pack.UpdateStorageCount = function ()
        {
            var store_count = $('#dup-pack-storage-panel input[name="_storage_ids[]"]:checked').length;
            $('#dpro-storage-title-count').html('(' + store_count + ')');
            (store_count == 0)
                    ? $('#dpro-storage-title-count').css({'color': 'red', 'font-weight': 'bold'})
                    : $('#dpro-storage-title-count').css({'color': '#444', 'font-weight': 'normal'});
        }
    });

//INIT
    jQuery(document).ready(function ($)
    {
        DupPro.Pack.UpdateStorageCount();
    });
</script>
