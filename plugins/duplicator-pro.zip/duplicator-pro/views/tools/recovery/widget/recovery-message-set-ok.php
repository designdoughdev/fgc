<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?><div class="dup-pro-recovery-message recovery-set-message-ok" >
    <!-- message from js -->
</div>