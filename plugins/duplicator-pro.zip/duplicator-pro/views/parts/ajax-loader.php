<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<div id="dup-pro-ajax-loader" >
    <div id="dup-ajax-loader-img-wrapper" >
        <img src="<?php echo esc_url(DUPLICATOR_PRO_PLUGIN_URL . '/assets/img/logo-black.svg'); ?>" alt="<?php _e('wait ...', 'duplicator-pro'); ?>">
    </div>
</div>