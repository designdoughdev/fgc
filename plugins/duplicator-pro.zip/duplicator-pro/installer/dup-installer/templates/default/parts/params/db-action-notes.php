<?php

/**
 *
 * @package templates/default
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?>
<span class="s2-warning-db-donothing requires-no-db">
    <i class="fa fa-exclamation-triangle"></i> With this option selected the database will not be installed.
    This is useful if you want to just extract the archive and not perform any actions on the database.
</span>
