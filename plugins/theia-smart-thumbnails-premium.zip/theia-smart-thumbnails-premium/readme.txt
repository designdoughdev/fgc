=== Theia Smart Thumbnails ===
Requires at least: 3.4
Tested up to: 5.9.1
Requires PHP: 5.3
